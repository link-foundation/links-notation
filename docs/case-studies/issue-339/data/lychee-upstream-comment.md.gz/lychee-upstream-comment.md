Additional reproducible evidence for the status-response distinction raised above: with Lychee 0.24.2 and `--max-retries 3`, a local endpoint returning 503 once and 200 thereafter receives exactly one request and Lychee exits 2. A second invocation succeeds; a persistent 404 control still fails.

Finite reproduction (three invocations, localhost only; no Docker):

```sh
python3 experiments/issue-339/probe_lychee_retry.py --lychee /path/to/lychee
```

The complete standalone script is in [link-foundation/links-notation PR 341](https://github.com/link-foundation/links-notation/pull/341), at `experiments/issue-339/probe_lychee_retry.py`. Output:

```json
{"path": "/flaky", "exit_code": 2, "cumulative_requests": 1, "successful": 0, "errors": 1}
{"path": "/flaky", "exit_code": 0, "cumulative_requests": 2, "successful": 1, "errors": 0}
{"path": "/gone", "exit_code": 2, "cumulative_requests": 1, "successful": 0, "errors": 1}
```

Our [CI run](https://github.com/link-foundation/links-notation/actions/runs/38102050110) failed twice on GitHub HTML file URLs returning 503. The first attempt had 21 occurrences across 13 distinct files. Live probes found all 13 raw-content equivalents returned 200, while a missing-file raw URL returned 404. A user-agent change alone did not prevent recurrence.

Workarounds we verified: recheck failures after a pause with caching, and remap only `https://github.com/OWNER/REPO/blob/REF/PATH` to the equivalent raw-content URL while retaining 404 failures. The latter now has a local server regression in the PR. Neither workaround reclassifies 503 as success.

For a code fix, aligning `RejectedStatusCode` retry classification with the intended bounded 5xx policy would make `--max-retries` govern actual HTTP responses as well as transport errors; regression cases should cover 503-then-200, persistent 503 exhausting the budget, and 404 remaining non-retryable. That alignment should be decided before adding the proposed subtractive selector. I am adding evidence here instead of opening a duplicate.
